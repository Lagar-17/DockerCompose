-- BASE DE DATOS LENVEL PARA LOS CURSOS

CREATE DATABASE lenvel_cursos;

USE lenvel_cursos;

CREATE TABLE cursos (

    ID_cursos INT AUTO_INCREMENT UNIQUE PRIMARY KEY,
    Titulo_curso VARCHAR(50) NOT NULL UNIQUE,
    Descripcion_curso VARCHAR(255) NOT NULL UNIQUE,
    Logo_curso VARCHAR(150) NOT NULL UNIQUE,
    Precio_curso FLOAT(9,2) NOT NULL
);

INSERT INTO cursos (Titulo_curso, Descripcion_curso, Logo_curso, Precio_curso) VALUES 
('Curso básico', 'Nivel de A1 a B1 con 1-3 años incluidos: Aprendizaje dinámico, clases presenciales y/o online', 'logo_basico.png', 1999.99),
('Curso básico + viaje', 'Nivel de A1 a B1 con 1-3 años incluidos: Aprendizaje dinámico, clases presenciales y/o online. ¡VIAJE INCLUIDO!', 'logo_basico_viaje.png', 3999.99),
('Curso avanzado', 'Nivel de B1+ con 1-3 años incluidos: Aprendizaje dinámico, clases presenciales y/o online', 'logo_avanzado.png', 2999.99),
('Curso avanzado + viaje', 'Nivel de B1+ con 1-3 años incluidos: Aprendizaje dinámico, clases presenciales y/o online. ¡VIAJE INCLUIDO!', 'logo_avanzado_viaje.png', 4999.99);
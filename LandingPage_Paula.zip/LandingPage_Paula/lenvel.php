<!-- PHP LENVEL -->

<?php
include 'conexion_lenvel.php';
// Importamos el archivo de conexión con la BBDD 
// Para asegurar la conexión riesgo a exposición de datos
?>

<!-- HTML PARA LA PÁGINA WEB -->

<!DOCTYPE html>
<html lang = "es">
  <!-- Idioma: español -->
  
  <head>

    <link rel = "stylesheet" type = "text/css" href = "lenvel.css">

    <!-- Enlace con el archivo enlazado que contiene el código CSS -->

    <link rel = "stylesheet" href = "https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel = "stylesheet" href = "https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css">

    <!-- Para enlazar las hojas de estilos -->

    <meta charset="UTF-8">

    <!-- Para caracteres especiales -->

    <meta name = "viewport" content = "width=device-width, initial-scale=1">

    <!-- 'name="viewport"' = área visible de una página web en el navegador -->
    <!-- 'content="width=device-width, initial-scale=1"' ajusta el ancho del viewport al ancho del dispositivo,
    define el nivel de zoom inicial cuando la página se carga (1 = 100% de escala) -->

    <meta name = "description" content = "Una landing page que ofrece cursos de idiomas con viaje al final del curso.">

    <!-- 'name = "description"' especifica que esta metaetiqueta contiene la descripción de la página -->
    <!-- 'content="..."' Contiene el texto descriptivo sobre la página -->

    <title>Lenvel</title>

    <!-- Define el título de la página web -->

  </head>


  <body>

    <!-- HEADER O PARTE SUPERIOR DE LA PÁGINA -->

    <header id="header">

      <div class="logo">
        <img class="logo-img" id="header-img"  src="logo_lenvel.png" alt="Lenvel logo" />
      </div>
      <!-- Para mostrar el logo de nuestro landing en el header -->

      <nav id="nav-bar">
        <ul>
          <li><a class="nav-link" href="#Descubrir">Descubrir</a></li>
          <li><a class="nav-link" href="#Beneficios">Beneficios</a></li>
          <li><a class="nav-link" href="#Cursos">Cursos</a></li>
          <li><a class="nav-link" href="#Recuerdos">Recuerdos</a></li>
          <li><a class="nav-link" href="#Contactar">Contactar</a></li>
        </ul>
      </nav>
      <!-- Para crear el menú superior de la página y poder crear enlaces que lleven a cada uno de las secciones de la web al clicar -->

    </header>

    <main>

      <!-- HERO O PRIMERA SECCIÓN DE LA PÁGINA -->

      <section id="hero" class="image">

        <div class="grid">
          <!-- Contenedor con diseño de rejilla para organizar los elementos -->

          <div class="column-60">

            <h1>Lenvel</h1>
            <!-- Título -->

            <p id="description">Aprende, conecta y explora con una aventura inolvidable.</p>
            <!-- Descripción o subtítulo -->

            <a href="#Contactar" class="btn">¡Lenvélate!</a>
            <!-- Nombre del botón, con formato de enlace para que nos lleve al formulario, es decir, a la sección "Contactar" al clicar -->

          </div>

        </div>

      </section>

      <!-- DESCUBRIR O SEGUNDA SECCIÓN DE LA PÁGINA -->

      <section id="Descubrir">
        <!-- Al seleccionar "Descubrir" en el menú del header, nos lleva a esta sección -->

        <h2>¿Cómo funciona nuestro programa?</h2>
        <!-- Título de la sección -->

        <div class="container">

          <div class="card">
            <!-- Para poder crear la el recuadro de información -->

            <div class="icon">
              <img  src="paso1.png" alt="Paso 1">
              <!-- La imágen/icono del recuadro de información -->

            </div>

              <div class="desc">
                <h3>Paso 1</h3>
                <p>Aprende el idioma que desees con nuestros +1.000 cursos personalizados.</p>
              </div>
              <!-- Para añadir el texto al recuadro -->

          </div>

          <div class="card">
            <!-- Segundo recuadro de información -->

            <div class="icon">
              <img  src="paso2.png" alt="Paso 2">
            </div>

            <div class="desc">
              <h3>Paso 2</h3>
              <p>Practica en un ambiente inmersivo y mejora tus habilidades.</p>
            </div>

          </div>

          <div class="card">
            <!-- Tercer recuadro de información -->

            <div class="icon">
              <img  src="paso3.png" alt="Paso 3">
            </div>

            <div class="desc">
              <h3>Paso 3</h3>
              <p>Viaja y aplica lo aprendido en la experiencia cultural final a uno de los +30 países con los que colaboramos.</p>
            </div>

          </div>

        </div>

      </section>

      <!-- BENEFICIOS O TERCERA SECCIÓN DE LA PÁGINA -->

      <section id="Beneficios">
        <!-- Al seleccionar "Beneficios" en el menú del header, nos lleva a esta sección -->

        <h2>Beneficios</h2>

        <div class="slider">
          <!-- Para crear el carrusel de imágenes -->

          <div class="slides">
              <!-- Cada una de los recuadros con el estilo "slide" que serán los ítems del slider, tenemos 5 en total -->
              
            <div class="slide" id="slide1">
              <p>Mejora fluida y rápida del idioma</p>
            </div>
            <!-- Contenido de los recuadros -->

            <div class="slide" id="slide2">
              <p>Experiéncia cultural auténtica con hablantes nativos</p>
            </div>

            <div class="slide" id="slide3">
              <p>Certificaciones 100% fiables y globales</p>
            </div>

            <div class="slide" id="slide4">
              <p>Clases dinámicas y métodos de enseñanza avanzados</p>
            </div>

            <div class="slide" id="slide5">
              <p>Viaje con todo incluido y guias profesionales</p>
            </div>

          </div> 

        </div>

      </section>

      <!-- CURSOS O CUARTA SECCIÓN DE LA PÁGINA -->

      <section id="Cursos">
        <!-- Al seleccionar "Cursos" en el menú del header, nos lleva a esta sección -->

        <h2>Descubre nuestros cursos</h2>

        <div class="container">

            <!-- PHP PARA LOS PRODUCTOS -->

            <?php

            $sql = "SELECT * FROM cursos;";
            // Consulta SQL para seleccionar todos los registros de la tabla "cursos"

            $resultado = $conn->query($sql);
            // Ejecutamos la consulta en la conexión a la base de datos

            // entramos en un bucle while para que genere un elemento div con una estructura predefinida por cada uno de los productos devueltos por la base de datos
            if($resultado->num_rows > 0) {
                // Verificamos si el resultado contiene filas (productos disponibles en la tabla)
                    
                while($curso = $resultado->fetch_assoc()){
                    // Recorremos los resultados con un bucle while
                    // Por cada fila obtenida, se crea un div con una estructura predefinida

                    echo '

                        <div class="card" id="curso_card">

                            <div class="logos_cursos">
                                <img class="logo-img" src="' . $curso['Logo_curso'] . '" alt="' . $curso['Titulo_curso'] . '">
                            </div>
                            
                            <div class="desc">

                                <h2>' . $curso['Titulo_curso'] . '</h2>

                                <ol>
                                    <li>' . $curso['Descripcion_curso'] . '</li>
                                </ol>

                                <span>' . $curso['Precio_curso'] . '€ </span>

                            </div>

                            <a href="#Contactar" class="btn">¡Lenvélate!</a>

                        </div>

                    ';
                    // Imprimimos el código para que se interprete en HTML, con el div de los cursos, que crea un total de 4 cards, una para cada curso en la BBDD

                }

            } else {
                echo '<p> No hay cursos disponibles </p>';
                // En caso de que no haya productos, se muestra un mensaje indicándolo
            }

            $conn->close();
            // Cerramos la conexión con la BBDD

            ?>

        </div>

      </section>
      
      <!-- RECUERDOS O QUINTA SECCIÓN DE LA PÁGINA -->

      <section id="Recuerdos">

        <h2>Recuerdos 2024</h2>

        <p>¿Te gustaría vivir la experiencia Lenvel y formar parte de nuestros +5k alumnos internacionales?</p>
        <!-- Texto superior de la sección -->

        <h3>¡Te esperamos, Lenvéate ya!</h3>
        <!-- Subtítulo de la sección -->

        <div class="galeria">
          <!-- Galeria de imágenes, al pasar sobre una, se amplia y te permite verla -->

          <img src="foto1.jpg" alt="Foto 1">
          <img src="foto2.jpg" alt="Foto 2">
          <img src="foto3.jpg" alt="Foto 3">
          <img src="foto4.jpg" alt="Foto 4">
          <img src="foto5.jpg" alt="Foto 5">
          <img src="foto6.jpg" alt="Foto 6">
          <img src="foto7.jpg" alt="Foto 7">
          <img src="foto8.jpg" alt="Foto 8">
          <img src="foto9.jpg" alt="Foto 9">
          <img src="foto10.jpg" alt="Foto 10">
          <img src="foto11.jpg" alt="Foto 11">
          <img src="foto12.jpg" alt="Foto 12">
          <img src="foto13.jpg" alt="Foto 13">
          <img src="foto14.jpg" alt="Foto 14">
          <img src="foto15.jpg" alt="Foto 15">
          <img src="foto16.jpg" alt="Foto 16">
          <img src="foto17.jpg" alt="Foto 17">
          <!-- Todas las imágenes en la galería -->

        </div>
        
      </section>

      <!-- CONTACTAR O FORMULARIO DE LA PÁGINA -->

      <section id="Contactar">

        <h2>Contactar</h2>

        <div class="grid">

          <div class="column-60">
            <!-- Columna que ocupa el 60% del espacio, para el formulario -->

            <form id="form" action="https://www.freecodecamp.com/email-submit">
              <!-- La acción especifica la URL a la que se enviarán los datos -->

              <div class="form-group">
                <!-- Grupo de entrada para el nombre -->

                <label id="nombre-label" for="nombre">Nombre</label>
                <!-- Subtítulo para el nombre de la persona que escribe el mensaje -->

                <input type="text" name="nombre" class="form-control" id="nombre" placeholder="Escriba aquí su nombre" required />
                <!-- Campo de entrada para el nombre -->
                <!-- 'required' hace que este campo sea obligatorio -->
              
              </div>

              <div class="form-group">

                <label id="email-label" for="email">Mail</label>
                <!-- Subtítulo para el mail de la persona que escribe el mensaje -->

                <input name="email" class="form-control" id="email" type="email" placeholder="Escriba aquí su dirección mail" required />
                <!-- 'type="email"' asegura que se ingrese un correo válido -->

              </div>

              <div class="form-group">

                <label id="asunto-label" for="asunto">Asunto</label>
                <!-- Subtítulo para el asunto del mensaje -->

                <input type="text" name="asunto" class="form-control" id="asunto" placeholder="Escriba aquí el asunto principal de su mensaje" required />

              </div>

              <div class="form-group">

                <p>Mensaje</p>
                <!-- Subtítulo del mensaje -->

                <textarea id="mensaje" class="input-textarea" name="mensaje" placeholder="Escriba aquí su mensaje"></textarea>
                <!-- Área de texto para que el usuario escriba su mensaje y se pueda "estirar" de la esquina inferior derecha-->
              
              </div>

              <div class="form-group">

                <label id="submit-label" for="submit">¡Gracias por lenveárte, te esperámos!</label>
                <!-- Texto superior al botón de "submit" -->

                <input id="submit" type="submit" value= "¡Lenvéate!" class="btn" />
                <!-- Botón para enviar el formulario -->
                <!-- 'type="submit"' envía los datos del formulario al servidor especificado en 'action' -->

              </div>

            </form>

          </div>

        </div>

      </section>

      <!-- FOOTER DE LA PÁGINA -->

      <footer>
        <!-- Footer de la página web -->

        <div id="logo_footer">
          <!-- Identificador para el logo del footer -->

          <img class="logo-img"  src="logo_lenvel.png" alt="Lenvel logo" />
          <!-- Imágen de pie de página -->

        </div>

        <div id="footer-info">
          <!-- Identificador para la información del footer -->

          <ul>
            <li><a href="#">Política de Privacidad</a></li>
            <li><a href="#">Soporte</a></li>
            <li><a href="#">Contacto</a></li>
          </ul>
          <!-- Información básica del footer -->

          <div id="copyright">Copyright 2024, Lenvel</div>
          <!-- Copyright -->

        </div>

      </footer>

    </main>

  </body>

</html>
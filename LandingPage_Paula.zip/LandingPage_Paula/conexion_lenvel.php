<!-- CONEXIÓN CON LA BASE DE DATOS DE LENVEL -->

<?php

// DECLARACIÓN DE VARIABLES PARA LA CONEXIÓN A LA BASE DE DATOS:

$servidor = "localhost"; 
// Dirección del servidor de la base de datos, en este caso, se utiliza el servidor local

$user = "root"; 
// Nombre de usuario de la base de datos (por defecto, "root" para servidores locales)

$pass = ""; 
// Contraseña del usuario (vacía por defecto en instalaciones locales)

$db = "lenvel_cursos"; 
// Nombre de la base de datos a la que se desea conectar

// CREACIÓN DE UNA NUEVA INSTANCIA PARA ESTABLECER LA CONEXIÓN:

$conn = new mysqli($servidor, $user, $pass, $db);

// COMPROBACIÓN DE ERRORES EN LA CONEXIÓN

if($conn->connect_error){ 
    die("Conexión fallida: " . $conn->connect_error);
    // Si ocurre un error, se termina la ejecución y se muestra un mensaje
}

?>
<?php include("includes/header.php"); ?> <!-- Este index tiene la funcion de redirigirnos a las paginas de acceso y registro  -->

	<h1>Porfavor inicie sesión o regístrese.</h1>

    
        <a class="btn btn-primary" href="acceso.php" role="button">Acceso</a> |
        <a class="btn btn-primary" href="registro.php" role="button">Registro</a>


<?php include("includes/footer.php"); ?>
<?php

include "conexion.php"; //llamamos a la base de datos y la iniciamos con el session_start()
session_start();
error_reporting(0); //esta funcion me desactiva todas las notificaciones de error
                    //sin esta funcion en los parametros de correo y contraseña me salen errores que no se como solucionar, aunque funcione bien el codigo.

if(isset($_SESSION["username"])){
    header("Location: pagina.php");
}

if(isset($_POST["submit"])){
    $email=$_POST["email"];
    $password=($_POST["password"]);
    
    $sql="SELECT * FROM users WHERE email='$email' AND password='$password'"; //Aquí lo que hacemos es buscar en la base de datos el usuario y el password y lo ponemos después en la variable result (resultado)
    $result= mysqli_query($conn, $sql);
    
    if($result->num_rows > 0){ //si hay un resultado que da positivo, es decir, que el usuario y contraseña no son 0 o más bien dicho que son entrados correctamente  nos envia a la pagina de que se ha iniciado correctamente la sesión, si no es asi nos dice que las credenciales no son validas
        $row = mysqli_fetch_assoc($result);
        $_SESSION['username'] = $row['username'];
        header("Location: pagina.php");
    }else{
        echo "<script>alert('Credenciales no validas')</script>";
    }
    
}


?>

<!-- Esta parte es la que seria el .html con el formulario -->
<?php include("includes/header.php"); ?>


	<div class="container">
		<form action="" method="POST" class="login-email">
			<h2 class="login-text">Acceso</h2>
			<div class="mb-3">
				<input type="email" placeholder="Escribe tu correo aquí" name="email" value="<?php echo $email; ?>" required>
			</div>
			<div class="mb-3">
				<input type="password" placeholder="Escribe tu contraseña aquí" name="password" value="<?php echo $_POST['password']; ?>" required>
			</div>
			<div class="mb-3">
				<button name="submit" class="btn btn-primary">Acceder</button>
			</div>
			<p class="login-register-text">No tienes cuenta? <a href="registro.php">Regístrate aquí</a>.</p>
		</form>
	</div>
	
	<?php include("includes/footer.php"); ?>
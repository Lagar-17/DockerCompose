<?php

include "conexion.php";
error_reporting(0);
session_start();


if(isset($_SESSION["username"]))
{
    header("Location: panel.php");
}

if(isset($_POST["submit"])){ //aqui hacemos que si el boton de submit que hay abajo es presionado que guarde en las supervariables los tados añadidos en en formulario
    $username=$_POST["username"];
    $email=$_POST["email"];
    $password= ($_POST["password"]);
    $cpassword= ($_POST["cpassword"]);
    
    
    if($password==$cpassword){ //aqui lo que hacemos es realizar una comparativa entre las dos contraseñas para ver si son iguales, hasta que las contraseñas no coincidan no nos cogeran los datos escritos en el formulario, a medida de que vayamos escribiendo mal o hayamos puesto un usuario ya registrado para regitrarse otra vez irán saltando errores.
        $sql="SELECT * FROM users WHERE email='$email'";
        $result= mysqli_query($conn, $sql);
        if(!$result->num_rows > 0){
            
            $sql="INSERT INTO users (username,email,password) VALUE ('$username', '$email', '$password')"; //aqui lo que hacemos es añadir los datos inscritos a traves del formulario a la base de datos.
            //los naranjas tiene que ver con el sql y los azules con el $_POST que tiene que ver con el name del formulario

            $result=mysqli_query($conn,$sql); //no necesito variable porque redireccionamos a la vista inicial
            
            if($result){ //aqui lo que hacemos mediante las variables de conn y sql hacemos que salga un echo con la confirmacion de que se ha registrado con exito o que ha habido un error.
                echo "<script>alert('Usuario $username, te has registrado correctamente.')</script>";
                $username="";
                $email="";
                $_POST["password"]="";
                $_POST["cpassword"]="";
                
            }else{
                echo "<script>alert('Hay un error')</script>";
            }
            
        }else{
            echo "<script>alert('Este correo ya esta inctrito anteriormente')</script>";
        }
    }else{
            echo "<script>alert('Las contraseñas no coinciden')</script>";        
    }
}

?>


<!-- Esta parte es la que seria el .html con el formulario -->
<?php include("includes/header.php"); ?>

	<div class="container">
		<form action="" method="POST" class="login-email">
            <h2 class="login-text">Registro</h2>
			<div class="mb-3">
				<input type="text" placeholder="Usuario" name="username" value="<?php echo $username; ?>" required>
			</div>
			<div class="mb-3">
				<input type="email" placeholder="Email" name="email" value="<?php echo $email; ?>" required>
			</div>
			<div class="mb-3">
				<input type="password" placeholder="Contraseña" name="password" value="<?php echo $_POST['password']; ?>" required>
            </div>
            <div class="mb-3">
				<input type="password" placeholder="Confirmar contraseña" name="cpassword" value="<?php echo $_POST['cpassword']; ?>" required>
			</div>
			<div class="mb-3">
				<button name="submit" class="btn btn-primary">Registrarme</button>
			</div>
            <p class="login-register-text">Ya tienes una cuenta creada? <a href="acceso.php">Inicia sesion aquí</a>.</p>
			
		</form>
	</div>
    <?php include("includes/footer.php"); ?>
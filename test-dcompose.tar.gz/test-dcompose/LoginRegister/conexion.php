<?php 

$servername="db";
$username="root";
$password="1234"; 
$database="users"; 

$conn = mysqli_connect($servername,$username,$password,$database);

if(!$conn){
    die("Conexión fallida: " . mysqli_connect_error());
}

?>

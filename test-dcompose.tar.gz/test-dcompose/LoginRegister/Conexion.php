<?php

$servername = "db";  // Nombre del servicio en docker-compose
$username = "root";
$password = "1234";  // La misma contraseña del docker-compose
$database = "users"; // Base de datos que crearemos

$conn = mysqli_connect($servername, $username, $password, $database);

if(!$conn){
    die("Conexión fallida: " . mysqli_connect_error());
}
?>
